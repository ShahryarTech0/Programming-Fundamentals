#include<stdio.h>
#include<math.h>

int area(float[]);

int main() {

	int i,max,j=1;
	float arr[6],side1,side2,Area,angle; // Variable declaration:
	
	for(i=0; i<6; i++) {  // Loop for getting data from the user:
	
		printf(" the plot No : %d :\n Enter the Side 1 and Side 2: ",j); // First and second side of triangle from the user :
		scanf("%f%f",&side1,&side2);
		
		printf(" the plot No : %d :\n Enter the Angle : ",j); // Taking angle from the user :
		scanf("%f",&angle);
		
		angle = angle * (3.142/180) ;	// Converting the given angle into radian :
		
		   Area = (0.5) * ( side1 * side2)*sin(angle);  // USing formula for calculating the area :
		        
		arr[i]=Area;
		printf("\nThe area of plot no: %d is = %.2f\n\n",j,Area);
		j++;
	}
	max=area(arr);
	
	printf("\nThe Largest area is of plot no : %d \n",max);
}
	int	area(float arr [])  // Function for the maxima area from the six
	{

	int i,j=0;
	float max=0;
	for(i=0; i<6; i++) { //   Finding the maximum :
			if(max<arr[i]) {
			max=arr[i];
			j=i;
			}
		}
	
	return (j+1);
}

