#include<stdio.h>
#include<string.h>
// prototype of sort function or declaration:

void  sort(int x,struct student s[100]);

// prototype of search_rol function or declaration(based on roll number):

void search_rol(int x,struct student s[100]);

// prototype of search_name function or declaration(based on name):

void search_name(int x,struct student s[100]);

struct student{  // Using structure:

	// Members of structure :
	int roll_no;
	char std_name[30]; 
	float std_marks;
}s[50];
int main(){
	int x,i,j=1,choice;
	
	// Asking the user number of students detail user wants to give input:
	printf("==> Enter the number of students ");
	scanf("%d",&x);
	struct student s[100];
	printf("\n==>> Enter the %d students details:\n",x);

	for(i=0;i<x;i++){
		
		//Students detail collecting from the user:
		
		printf("\n==>> Enter the %d students roll no:",j);
		scanf("%d",&s[i].roll_no);
		fflush(stdin);
		printf("==>> Enter the %d students name :",j);
		gets(s[i].std_name);
		printf("==>>Enter the %d students marks:",j);
		scanf("%f",&s[i].std_marks);
		j++;
}
// Menu of detail:

printf("\n==================================\n\n====>>	WELCOME TO STUDENTS INFO OFFICE	<<=====\n\n\n");
	printf("\n====>>	1. Sorting the marks of students press 1\n====>>	2. Search data based on roll no: press 2\n====>>	3. Search data based on name: press 3 \n\n==================================\n");
	printf("\n====>>	Please select your choice:"); // Asking the choice from the user from above menu:
	scanf("%d",&choice);
	
	switch(choice)
	{
		case 1:
			sort(x,s);
			break;
		case 2:
			search_rol(x,s);
		break;
		case 3:
			search_name(x,s);
		break;
	default:
		printf("\n====>>	You have entered incorrect command:\n");
	}
	
}
void  sort(int x,struct student s[100]) // function for sorting all the marks:
{
	int i,j=1,n,k;
	char arr[50];
	for(i=0;i<x;i++){
		for(j=0;j<x;j++){	
			// sorting the marks:
			
			if(s[i].std_marks>s[j].std_marks)
			{
			n=s[i].std_marks;
			s[i].std_marks=s[j].std_marks;
			s[j].std_marks=n;
			
			// sorting the names:
			
		strcpy(arr,s[i].std_name);
		strcpy(s[i].std_name,s[j+1].std_name);
		strcpy(s[j+1].std_name,arr);
		
		// sorting the roll numbers:
		
		n=s[i].roll_no;
			s[i].roll_no=s[j].roll_no;
			s[j].roll_no=n;
			
		}
		}
		}
	printf("\n====>>	 after sorting :\n");
	
	printf("Roll number	Names		marks\n\n");
	for(i=0;i<x;i++)
	{   
		// Displaying the names after the sorting:
	 	
		printf("%d		%s		%.1f",s[i].roll_no,s[i].std_name,s[i].std_marks);
		fflush(stdin);
		printf("\n");
	}
	
}
void search_rol(int x,struct student s[100])
 {
 	int i,j,choice;
 	printf("\nPlease enter the roll number for watching the data:");
 	scanf("%d",&choice);
 	for(i=0;i<x;i++){
 		if(s[i].roll_no==choice)
 		{
 			printf("\n==================================\n\n====>>	Roll no: %d\n====>>	name : %s\n====>>	marks= %.2f\n\n==================================\n",s[i].roll_no,s[i].std_name,s[i].std_marks);
		 }
	 }
 	
 	
 }
 
 void search_name(int x,struct student s[100])
 {
 	int i,j=0;
 	char n[30];
 	printf("\nPlease enter the name of student for watching the data:");
	scanf("%s",&n);
 	for(i=0;i<x;i++){
 		if(strcmp(n,s[i].std_name) ==0)
 		{
 			printf("\n==================================\n\n====>>	Roll no: %d\n====>>	name : %s\n====>>	marks= %.2f\n\n==================================\n",s[i].roll_no,s[i].std_name,s[i].std_marks);
 			j++;
		 }
	 }
	 if(j==0){
	 	printf("\n====>>	Sorry you have entered the incorrect name:\n");
	 }
 	
 	
 }
