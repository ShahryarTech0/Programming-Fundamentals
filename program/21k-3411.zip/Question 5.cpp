#include<stdio.h>

void sort(int arr[100],int x);

int main(){
	int i,x;
	printf("Enter the size of array:");
	scanf("%d",&x);
	int arr[x];
	printf("Enter the array elements: ");
	for(i=0;i<x;i++){
		scanf("%d",&arr[i]);
	}
	sort(arr,x); // calling the function and passing the array address and size of array:
	
	printf("The array after sorting  ");
	for(i=0;i<x;i++){
		printf("%d\n",arr[i]);
	}
}
void sort(int arr[100],int x)
{
	int i ,j,num=0;
	for(i=0;i<x;i++){
		for(j=0;j<x;j++){
			if(arr[i] > arr[j+1]){
				num=arr[i];
				arr[i]=arr[j+1];
				arr[j+1]=num;
			}
		}
	}
	printf("%d\n",arr[2]);
}
