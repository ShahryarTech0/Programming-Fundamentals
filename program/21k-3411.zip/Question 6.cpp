#include<stdio.h>

int increment(int[],int);

int main(){
	int i,x;

	printf("Enter the size of array:");
	scanf("%d",&x);
	int arr[x];
	printf("Enter the %d  elements",x);
	for(i=0;i<x;i++){
		scanf("%d",&arr[i]);
	}
	increment(arr,x);
	printf("\nAfter increment by two : array is :\n\n");
	for(i=0;i<x;i++){
	printf("%d\n",arr[i]);
	}
}
int increment(int arr [],int x)
{
		int i;

	for(i=0;i<x;i++){
		arr[i]=arr[i]+2;
	}
	return arr[x];
}
