#include<stdio.h>
int rec_func(int num); //function declaration
void main()
{
    int num, rec=0,i;
    for(i=1;i<6;i++){
	
    printf("Enter the number %d is : ",i);
    scanf("%d", &num);

    rec += rec_func(num); //Call the value
}
    printf("\nThe sum using recursion = %d",rec);
}

int rec_func(int num)  //Name for identification
{
    if (num==0)
    {
        return 0;
    }

    return (num%10+rec_func(num/10));
}

