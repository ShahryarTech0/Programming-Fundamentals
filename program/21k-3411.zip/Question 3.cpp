#include<stdio.h>
int sum(int x){
	int sum=0,remainder,i;
	for(i=0;i<=4;i++){
		remainder=x%10; x=x/10;
		sum=sum+remainder;
	}
	return sum;

}
int main()
{
	int x,n;
	printf("Enter the five number");
	scanf("%d",&x);
	if(x>9999 && x<100000){
	n=sum(x);
	printf("Sum is %d ",n);
}
else{
	printf("Warning!!!  try again:");
}

}
