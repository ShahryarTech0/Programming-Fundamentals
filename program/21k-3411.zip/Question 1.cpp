#include<stdio.h>


float result(int);  // Function declaration or prototype:

int main(){
	float avg;
	int n,total_marks;
	printf("Enter the number of subjects:");
	scanf("%d",&n);
	printf("Enter the total marks:");
	scanf("%d",&total_marks);
	avg=result(n);
	printf("\n>>>>The average of all subjects : %.2f <<<<\n",avg);
	
	printf("\n===>>the percentage is : %.2f<<===",(avg*n*100)/total_marks);
}
float result(int n)
{
	int i,sum=0;
	float avg,x;
	for(i=1;i<=n;i++){
		printf("\nEnter the subject %d marks:\n",i);
		scanf("%f",&x);
		sum=sum+x;
	}
	avg=1.0*sum/n;
	return avg;
}
