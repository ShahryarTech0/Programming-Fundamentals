#include<stdio.h>
#include<conio.h>
#include<string.h>

// COUNT function decalration :

int count();

// DISPLAY function declaration:
void display(int); 

// AUTHOR BOOKS function decalration:
void author_books(char*);

// Function decalaration:
void book_info();

// function declaration:
void title_book(int);

// function declaration:
void display_accession();


// definig the structure function:
struct library
{
	// Members of structure function:
	int No;/*Accession number*/
	char title[50];
	char author[30];
	int price;
	int flag; // if flag is zero means issued and one means not issued
}lib_books[50] = { // Some books  and their prices :
	1, "The c programming langauge", "Greg perry and Dean miller", 600, 1,
	2, "C++ Primer","Grey B", 560, 1,
	3, "Let Us C++", "Yashavant Kanethkar", 740, 1,
	4, "A smart way to learn javascript :", "Mark Mayers", 550, 0,
	5, "The Two Towers", "J. R. R. Tolkien", 360, 0,
	6, "The Hobbit", "J. R. R. Tolkien", 950, 1,
	7, "Python data science handbook", "Jake VanderPlas", 580, 0
};

// Main function:
int main()
{
	struct library s[100];
	int choice = 1, No,arr[100];
	char auth[30];
	while (choice != 7)
	{	// Menu of library:
	
		printf("\nYou are in  :LIBRARAY MENU :section\n");
		printf("\n1. Add Book Information");
		printf("\n2. Display Book Information");
		printf("\n3. List all books of given author");
		printf("\n4. List the title of specified book");
		printf("\n5. List the counts of the books in library");
		printf("\n6. List the books in order of accession number");
		printf("\n7. Exit");
		printf("\n\n\t\tEnter you choice : ");
		scanf("%d", &choice);
		switch (choice)
		{
		case 1:
			book_info(); // calling the function :
			_getch();
			break;
		case 2: 
			printf("\nEnter the accession number of the book : ");
			scanf("%d", &No);
			display(No); // calling the function and passing the arguement:
			_getch();
			break;
		case 3:
			while (getchar() != '\n');
			printf("Enter the name of the author  : ");
			gets(auth);
			author_books(auth); // calling the function and passing the arguement:
			_getch();
			break;
		case 4:
			printf("\nEnter the accession number of book : ");
			scanf("%d", &No);
			title_book(No); // calling the function and passing the arguement:
			_getch();
			break;
		case 5:
			printf("\nTotal Number of books : %d", count());
			_getch();
			break;
		case 6:
			display_accession();  // calling the function and passing the no arguement:
			_getch();
			break;
		case 7:
			return 0;
		default:
			printf("\nWrong choice, Try Again!!");
			_getch();

		}
	}
	_getch();
	return 0;
}

int count()
{
	int i = 0;
	while (lib_books[i].No)
		i++;
	return i;
}

void display(int i)
{
	i--;  // Dsiplaying the book according to the accession number:
	printf("\n\n\n");
	printf("\nAccession Number : %d", lib_books[i].No);
	printf("\nTitle : %s", lib_books[i].title);
	printf("\nAuthor : %s", lib_books[i].author);
	printf("\nPrice : %d", lib_books[i].price);
	if (lib_books[i].flag)/*Flag : 0*/
		printf("\nStatus : Issued");
	else
		printf("\nStatus : Available");/*Flag : 1*/
}

void author_books(char *author)
{
	int i = 0;
	printf("\nBooks of \"%s\" are following : \n\n", author);
	while (lib_books[i].No)
	{
		if (!(strcmp(author, lib_books[i].author))) // comparing the strings:
			display(lib_books[i].No);
		i++;
	}
}

void book_info()
{
	int next = count();
	lib_books[next].No = next + 1;

	/*fflush(stdin) or while(getch() != '\n'); to clear the buffer*/
	while (getchar() != '\n');
	printf("\nEnter the title of the book : ");
	gets(lib_books[next].title);
	printf("\nEnter the author name of the book : ");
	gets(lib_books[next].author);
	printf("\nEnter the price of the book : ");
	scanf("%d", &lib_books[next].price);
	lib_books[next].flag = 1;
}

void title_book(int No)
{
	int i = 0;
	while (lib_books[i].No)
	{
		if (lib_books[i].No == No)
		{
			printf("\n\nTitle of the book : %s\n", lib_books[i].title);
			return;
		}
	}
	printf("No any book found \n");
}

void display_accession()
{
	int i = 0;
	while (lib_books[i].No)
	{
		display(i + 1);
		i++;
	}
}
