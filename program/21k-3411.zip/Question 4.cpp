#include<stdio.h>
int display(int []);
int main(){
	int arr[10],i,sum=0;
	printf("Enter the Ten(10) elements:");
	for(i=0;i<10;i++){
		scanf("%d",&arr[i]);
		sum=sum+arr[i];
	}
	display(arr);
	printf("Sum is %d\n",sum);
	printf("Min is %d\n",arr[0]);
	printf("Max is %d\n",arr[1]);
}
int display(int arr[])
{
	int i,j,temp;
	for(i=0;i<10;i++){

		for(j=0;j<10;j++){
			if(arr[i]>arr[j+1]){
				temp=arr[i];
				arr[i]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
	return arr[10];
}
