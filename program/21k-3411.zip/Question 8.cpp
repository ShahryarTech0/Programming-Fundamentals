#include<stdio.h>

// declaration of functions:

struct dates display(struct dates,struct dates);
struct dates input1(void);
struct dates input2(void);

// Structure functions:

struct dates
{
	// Members of structure function:
	
	int date; 
	int month;
	int year;
	
};


int main(){
	struct dates a,b;  // Variables of dates: 
	a=input1(); // calling the input1 function:
	b=input2(); // // calling the input2 function:
	display(a,b); // calling the display function and passing the actual arguements:
}

struct dates input1(void)
{
	struct dates a;
	
	//  Taking input from the user of date, month and year:
	
	printf("No 1: Enter the date , month and year");
	scanf("%d%d%d",&a.date,&a.month,&a.year);
	
	return (a); // returns the structue variable:
}
struct  dates input2()
{
	struct dates b;
	
	//  Taking input from the user of date, month and year:
	
	printf("No 2: Enter the date , month and year");
	scanf("%d%d%d",&b.date,&b.month,&b.year);
	return (b);	// returns the structue variable:
}
struct dates display(struct dates a,struct dates b)
{	
	// Checking the condtions:
	
	if(a.date==b.date&&a.month==b.month && a.year==b.year){
		printf("Both are equal");
	}
	else {
		printf("Not equal :");
	}
}
